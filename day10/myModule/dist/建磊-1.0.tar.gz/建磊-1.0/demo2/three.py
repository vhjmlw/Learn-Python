# coding:utf-8 -*-

'demo2包的three模块'

__author__ = '建磊'

def func():
    print('three')
