# coding:utf-8 -*-

'demo2包的four模块'

__author__ = '建磊'

def func():
    print('four')
