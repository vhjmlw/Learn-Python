from distutils.core import setup

setup(name='建磊',version='1.0',description='建磊自己的模块',author='建磊',py_modules=['demo1.one','demo1.two','demo2.three','demo2.four'])
