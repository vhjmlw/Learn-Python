# -*- coding:utf-8 -*-

'demo包里面的two模块'

__author__ = '建磊'

def func():
    print('demo1 two func')
