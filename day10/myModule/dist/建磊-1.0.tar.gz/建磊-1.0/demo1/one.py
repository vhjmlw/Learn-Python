# -*- coding:utf-8 -*-

'demo1包中的one模块'

__author__ = '建磊'

def func():
    print('demo1 one one')
